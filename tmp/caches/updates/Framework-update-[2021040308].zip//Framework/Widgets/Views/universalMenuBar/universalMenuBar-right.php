<!--<article>
    <header>
        <hgroup>
            <h5 style="text-transform: uppercase"> Search Anything..</h5>
        </hgroup>
    </header>
    <div class="col-lg-8 col-md-8"><label>
            <input type="text" class="input-control">
        </label></div>
    <input type="button" class="button button-outline-primary" value="Search">

</article>

<article>
    <header>
        <hgroup>
            <h5 style="text-transform: uppercase"> WHY CHOOSE US</h5>
        </hgroup>
    </header>
    <ul class="pgSidebarItems">
        <li class="pgSidebarItemsBody">
            <div class="pgSidebarItemsBodyTitle"> We’ll Respond Within 2 hours or Less.</div>
            <div class="pgSidebarItemsBodyButton"> +</div>
            <div class="pgSidebarItemsBodyText">
                When you call us with a problem in our any product, we ensure you that your phone
                call will be either answered immediately or
                returned within 2 hours or less by an experienced technician who can help.
                If we fail to respond within that time frame, a reduction given on your fixed
                monthly fee.
            </div>
        </li>
        <li class="pgSidebarItemsBody">
            <div class="pgSidebarItemsBodyTitle">100% Unconditional Satisfaction Guarantee</div>
            <div class="pgSidebarItemsBodyButton">+</div>
            <div class="pgSidebarItemsBodyText">
                You deserve complete satisfaction with our products and services. We will do
                whatever it takes to make you happy. No hassles, no problems.
            </div>
        </li>
        <li class="pgSidebarItemsBody">
            <div class="pgSidebarItemsBodyTitle">Everything On Time and On Budget +</div>
            <div class="pgSidebarItemsBodyButton">+</div>
            <div class="pgSidebarItemsBodyText">
                You deserve complete satisfaction with our products and services. We will do
                whatever it takes to make you happy. No hassles, no problems.
            </div>
        </li>
        <li class="pgSidebarItemsBody">
            <div class="pgSidebarItemsBodyTitle">When you need to be Efficient.</div>
            <div class="pgSidebarItemsBodyButton">+</div>
            <div class="pgSidebarItemsBodyText">
                You deserve complete satisfaction with our products and services. We will do
                whatever it takes to make you happy. No hassles, no problems.
            </div>
        </li>
    </ul>
    <footer><a href="/web/why-mishusoft.php" class="readmore text-shadow-button">Read More..</a></footer>
</article>-->