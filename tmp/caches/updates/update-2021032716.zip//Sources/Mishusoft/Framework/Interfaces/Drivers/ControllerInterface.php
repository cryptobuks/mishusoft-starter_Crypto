<?php


namespace Mishusoft\Framework\Interfaces\Drivers;


interface ControllerInterface
{
    public function index();

}