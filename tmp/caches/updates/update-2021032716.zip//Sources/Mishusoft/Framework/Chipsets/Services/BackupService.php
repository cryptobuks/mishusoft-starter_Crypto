<?php


namespace Mishusoft\Framework\Chipsets\Services;


class BackupService
{
    public function __construct()
    {
        
    }

    public function __destruct()
    {
        
    }

}