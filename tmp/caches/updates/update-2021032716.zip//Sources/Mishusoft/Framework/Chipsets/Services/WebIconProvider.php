<?php


namespace Mishusoft\Framework\Chipsets\Services;


class WebIconProvider
{

}