<?php

namespace Mishusoft\Framework\Chipsets;

/*automatically load all required classes*/


define("PHP_CODE_SYNTAX", "PHP7.4.3");
define("WHO_AM_I", "Mishusoft");
define('MS_SERVER_NAME', array_key_exists("SERVER_NAME", $_SERVER) ? $_SERVER['SERVER_NAME'] : "localhost");
define("PHP_RUNTIME_ROOT_PATH", realpath(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR);
define("PHP_RUNTIME_SYSTEM_PATH", PHP_RUNTIME_ROOT_PATH . 'Framework' . DIRECTORY_SEPARATOR);
define("PHP_RUNTIME_SYSTEM_TEMP_PATH", PHP_RUNTIME_ROOT_PATH . 'tmp' . DIRECTORY_SEPARATOR);
/*define("PHP_RUNTIME_REGISTRIES_PATH", PHP_RUNTIME_SYSTEM_PATH . 'Registries' . DIRECTORY_SEPARATOR);*/
define("PHP_RUNTIME_REGISTRIES_PATH", PHP_RUNTIME_ROOT_PATH . 'tmp/caches/configs' . DIRECTORY_SEPARATOR);
//define('MS_REGISTRIES_PATH', PHP_RUNTIME_ROOT_PATH . 'tmp/caches/configs' . DIRECTORY_SEPARATOR);
define("PHP_RUNTIME_LOGS_PATH", PHP_RUNTIME_ROOT_PATH . 'tmp/logs' . DIRECTORY_SEPARATOR);
//define('MS_SYSTEM_LOGS_PATH', PHP_RUNTIME_ROOT_PATH . 'tmp/logs' . DIRECTORY_SEPARATOR);

/*files location declare*/
define('PHP_ACCESS_LOG_FILE', PHP_RUNTIME_LOGS_PATH . 'php_access_' . MS_SERVER_NAME . '.log');
define('PHP_COMPILE_LOG_FILE', PHP_RUNTIME_LOGS_PATH . 'php_compile_' . MS_SERVER_NAME . '.log');
define('PHP_RUNTIME_LOG_FILE', PHP_RUNTIME_LOGS_PATH . 'php_runtime_' . MS_SERVER_NAME . '.log');


Autoload::loadFile([
    join(DIRECTORY_SEPARATOR, [PHP_RUNTIME_ROOT_PATH . "Composer", "vendor", "autoload.php"]),
    PHP_RUNTIME_SYSTEM_PATH . 'Chipsets/Preloader.php',
    PHP_RUNTIME_SYSTEM_PATH . 'Chipsets/System/Logger.php'
]);
//Autoload::loadFile(PHP_RUNTIME_SYSTEM_PATH . 'Chipsets/Preloader.php');
//Preloader::loadGlobals(PHP_RUNTIME_SYSTEM_PATH . 'PreRequires');
Autoload::register();

/*set customize error controller*/
set_error_handler(function ($errorNo, $errorMessage, $errorFile, $errorLine) {
    return new RuntimeErrors($errorMessage, $errorNo, $errorNo, $errorFile, $errorLine);
}, E_ALL);


/**
 * Simple autoloader, so we don't need Composer just for this.
 */
class Autoload
{
    /*set exclude directories for file load*/
    const excludeDirs = array(".", "..", "Backups", "Pagination", "Themes");

    public static function register(/*$log_file*/)
    {
        spl_autoload_register(function (string $class) /*use ($log_file)*/ {
            /*check file is use namespace*/
            if (strpos($class, '\\')) {
                /*self::log("Want to load PSR File $class.");*/
                //$file = str_replace('\\', DIRECTORY_SEPARATOR, $class) . '.php';
                /*self::log("Retrieve class name to file name: $file.");*/
                //$original_file = PHP_RUNTIME_ROOT_PATH . substr($file, strlen(WHO_AM_I) + 1, strlen($file));
                $original_file = Preloader::getPathFromClassNamespace($class);
                if (is_file($original_file)) {
                    /*self::log("Checking local file: $original_file.");*/
                    if (file_exists($original_file)) {
                        include_once $original_file;
                        /*self::log("Included local file: $original_file.");*/
                    }
                } /*else {
                    self::log("Failed to load $class From $original_file.");
                }*/
            } else {
                /*self::log("Want to load normal File $class.");*/

                foreach (scandir(realpath(dirname(dirname(__FILE__)))) as $index => $directory) {
                    if (!in_array($directory, self::excludeDirs)) {
                        /*self::log(join(["Checking local file: ", PHP_RUNTIME_SYSTEM_PATH, ucfirst($directory), "/", ucfirst($class), ".php"]));*/
                        if (file_exists(join(DIRECTORY_SEPARATOR, [PHP_RUNTIME_SYSTEM_PATH . ucfirst($directory), ucfirst($class) . ".php"]))) {
                            include_once join(DIRECTORY_SEPARATOR, [PHP_RUNTIME_SYSTEM_PATH . ucfirst($directory), ucfirst($class) . ".php"]);
                            /*self::log(join(["Included local file: ", PHP_RUNTIME_SYSTEM_PATH, ucfirst($directory), "/", ucfirst($class), ".php"]));*/
                        }
                    }
                }
            }
        });
    }

    /**
     * @param array $filename
     */
    public static function loadFile(array $filename)
    {
        if (count($filename) > 0) {
            foreach ($filename as $file) {
                if (file_exists($file)) {
                    require_once $file;
                } else {
                    trigger_error("$file not found");
                }
            }
        }

    }

}
