<!--<div class="col-3 col-s-3 left-menu">
    <ul>
        <li>The Flight</li>
        <li>The City</li>
        <li>The Island</li>
        <li>The Food</li>
    </ul>
</div>-->