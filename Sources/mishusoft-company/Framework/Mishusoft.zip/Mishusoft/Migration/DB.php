<?php


namespace Mishusoft\Migration;

class DB
{
    public const NAME = DB_DEFAULT_NAME;
    public const USER = DEFAULT_OPERATING_SYSTEM_USER;
    public const PASSWORD = DEFAULT_OPERATING_SYSTEM_PASSWORD;
}
