<?php


namespace Mishusoft\Exceptions\RuntimeException;

use Mishusoft\Exceptions\RuntimeException;

/**
 * Exception thrown if a file or directory not found in system.
 */
class NotFoundException extends RuntimeException
{
}
