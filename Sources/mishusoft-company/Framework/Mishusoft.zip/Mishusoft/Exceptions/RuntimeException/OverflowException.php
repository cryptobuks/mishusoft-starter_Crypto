<?php


namespace Mishusoft\Exceptions\RuntimeException;

use Mishusoft\Exceptions\RuntimeException;

/**
 * Exception thrown when you add an element into a full container.
 */
class OverflowException extends RuntimeException
{
}
