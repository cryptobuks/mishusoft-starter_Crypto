<?php


namespace Mishusoft\Exceptions\RuntimeException;

use Mishusoft\Exceptions\RuntimeException;

/**
 * Exception thrown when you try to remove an element of an empty container.
 */
class UnderflowException extends RuntimeException
{
}
