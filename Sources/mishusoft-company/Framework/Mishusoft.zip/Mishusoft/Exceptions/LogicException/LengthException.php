<?php


namespace Mishusoft\Exceptions\LogicException;

use Mishusoft\Exceptions\LogicException;

/**
 * Exception thrown if a length is invalid.
 */
class LengthException extends LogicException
{
}
