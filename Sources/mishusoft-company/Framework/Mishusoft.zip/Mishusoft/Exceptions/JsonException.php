<?php


namespace Mishusoft\Exceptions;

class JsonException extends Handler
{
}
