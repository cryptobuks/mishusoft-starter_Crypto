<?php


namespace Mishusoft\Exceptions;

class ErrorException extends Handler
{

}
