<?php


namespace Mishusoft\Exceptions\HttpException;

use Mishusoft\Exceptions\HttpException;

class HttpInvalidParamException extends HttpException
{
}
