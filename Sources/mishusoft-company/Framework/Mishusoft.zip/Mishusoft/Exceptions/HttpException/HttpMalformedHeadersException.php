<?php


namespace Mishusoft\Exceptions\HttpException;

use Mishusoft\Exceptions\HttpException;

class HttpMalformedHeadersException extends HttpException
{
}
