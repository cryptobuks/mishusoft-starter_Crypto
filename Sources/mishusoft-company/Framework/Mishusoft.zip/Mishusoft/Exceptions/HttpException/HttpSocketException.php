<?php


namespace Mishusoft\Exceptions\HttpException;

use Mishusoft\Exceptions\HttpException;

class HttpSocketException extends HttpException
{
}
