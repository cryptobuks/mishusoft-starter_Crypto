<?php


namespace Mishusoft\Exceptions\HttpException;

use Mishusoft\Exceptions\HttpException;

class HttpRequestMethodException extends HttpException
{
}
