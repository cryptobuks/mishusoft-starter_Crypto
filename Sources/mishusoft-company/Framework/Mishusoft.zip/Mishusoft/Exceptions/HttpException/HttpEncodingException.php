<?php


namespace Mishusoft\Exceptions\HttpException;

use Mishusoft\Exceptions\HttpException;

class HttpEncodingException extends HttpException
{
}
