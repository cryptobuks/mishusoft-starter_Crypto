<?php


namespace Mishusoft\Exceptions;

class DbException extends Handler
{

}//end class
