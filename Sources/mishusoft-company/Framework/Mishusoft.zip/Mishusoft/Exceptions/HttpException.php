<?php


namespace Mishusoft\Exceptions;

class HttpException extends Handler
{
    public $innerException;
}
