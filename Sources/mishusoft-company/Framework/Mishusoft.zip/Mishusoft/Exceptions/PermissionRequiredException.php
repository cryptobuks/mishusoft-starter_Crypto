<?php


namespace Mishusoft\Exceptions;

/**
 * This exception is thrown when the service requires permission to access.
 */
class PermissionRequiredException extends Handler
{
}