<?php

namespace Mishusoft;

class RAM extends Base
{

    protected array $providers =[
        ''=>'',
    ];

    private array $access =[];



    public function __construct()
    {
    }

    public static function activate()
    {


        
    }
}
