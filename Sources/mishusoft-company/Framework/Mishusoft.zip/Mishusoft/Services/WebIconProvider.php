<?php declare(strict_types=1);


namespace Mishusoft\Services;


class WebIconProvider
{

}