<?php declare(strict_types=1);


namespace Mishusoft\Databases;


class MySqli extends \mysqli
{

}