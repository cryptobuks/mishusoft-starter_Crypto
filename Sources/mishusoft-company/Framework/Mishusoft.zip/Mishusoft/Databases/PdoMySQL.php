<?php declare(strict_types=1);


namespace Mishusoft\Databases;


use PDO;

class PdoMySQL extends PDO
{
}