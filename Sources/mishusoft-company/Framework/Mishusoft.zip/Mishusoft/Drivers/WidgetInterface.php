<?php


namespace Mishusoft\Drivers;


interface WidgetInterface
{

}