<?php


namespace Mishusoft\Drivers;


interface ControllerInterface
{
    public function index();

}