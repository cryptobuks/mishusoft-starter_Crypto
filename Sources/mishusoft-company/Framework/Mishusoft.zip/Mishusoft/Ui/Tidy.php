<?php

namespace Mishusoft\Ui;

class Tidy extends \tidy
{

}