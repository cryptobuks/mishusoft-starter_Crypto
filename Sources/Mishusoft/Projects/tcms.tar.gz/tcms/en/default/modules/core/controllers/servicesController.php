<?php

class servicesController extends Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->access_init();
    }

    public function index()
    {
    }
}