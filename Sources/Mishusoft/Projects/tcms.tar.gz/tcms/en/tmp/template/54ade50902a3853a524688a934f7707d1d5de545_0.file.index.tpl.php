<?php
/* Smarty version 3.1.33, created on 2019-05-22 11:26:58
  from '/home/mishusoft/public_html/releases/tcms/en/default/modules/core/views/pages/appmanager/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ce4dda273cf39_89363479',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '54ade50902a3853a524688a934f7707d1d5de545' => 
    array (
      0 => '/home/mishusoft/public_html/releases/tcms/en/default/modules/core/views/pages/appmanager/index.tpl',
      1 => 1557234931,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ce4dda273cf39_89363479 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <fieldset class="box-shadow-light">
            <legend class="box-shadow-light"> App Manager</legend>
            <div class="row" id="adminMenus">
                <div class="thumbnail box-shadow-light">
                    <div class="thumbnail-image"><i class="fas fa-wrench"></i></div>
                    <div class="thumbnail-text">Loading..</div>
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php }
}
